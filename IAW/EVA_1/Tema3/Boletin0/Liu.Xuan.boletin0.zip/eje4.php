<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>HTML</title>
    <meta name="viewport" content="width = device_width, initial-scale=1.0">
</head>
<body>
    <h1>Boletin 0. Operadores</h1>
    <h2> 
    Calcule la media aritmética de 3 números cualesquiera
    </h2>
    <?php
      //Aqui empieza el programa
      //Variables
        $num1 = 34;
        $num2 = 64;
        $num3 = 13;

        $medio = ($num1 + $num2 + $num3)/3;
      
      //resulta
        echo "El medio de los numeros: $num1, $num2 y $num3 es $medio";
    ?>
</body>
</html>